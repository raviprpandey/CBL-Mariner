# Secret-Stores

This folder contains the plugins for the secret-store functionality:

* docker: Docker Secrets within containers
* http: Query secrets from an HTTP endpoint
* jose: Javascript Object Signing and Encryption
* os: Native tooling provided on Linux, MacOS, or Windows.

See each plugin's README for additional details.
