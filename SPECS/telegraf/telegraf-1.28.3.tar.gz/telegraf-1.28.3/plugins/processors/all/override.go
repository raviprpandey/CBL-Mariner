//go:build !custom || processors || processors.override

package all

import _ "github.com/influxdata/telegraf/plugins/processors/override" // register plugin
