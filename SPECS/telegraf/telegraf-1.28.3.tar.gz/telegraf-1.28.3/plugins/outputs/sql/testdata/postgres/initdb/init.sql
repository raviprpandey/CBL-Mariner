create database foo;

